<?php

require '../model/peliculaModel.php';

class peliculaController
{
    private $model;

    public function __construct()
    {
        $db = new PDO('mysql:host=localhost;dbname=peliculas', 'root', '');
        $this->model = new peliculaModel($db);
    }

    public function getPeliculas()
    {
        return $this->model->getPeliculas();
    }

    public function getPeliculaById($id)
    {
        return $this->model->getPeliculaById($id);
    }

    public function createPelicula($titulo, $gen_id, $anio_lanzamiento, $link_img)
    {
        return $this->model->createPelicula($titulo, $gen_id, $anio_lanzamiento, $link_img);
    }

    public function updatePelicula($id, $titulo, $gen_id, $anio_lanzamiento, $link_img)
    {
        return $this->model->updatePelicula($id, $titulo, $gen_id, $anio_lanzamiento, $link_img);
    }

    public function deletePelicula($id)
    {
        return $this->model->deletePelicula($id);
    }
}
?>
