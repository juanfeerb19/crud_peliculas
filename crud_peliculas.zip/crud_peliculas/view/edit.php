<?php
require '../controller/peliculaController.php';

$controller = new PeliculaController();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pelicula_id = $_POST['pelicula_id'];
    $titulo = $_POST['titulo'];
    $gen_id = $_POST['gen_id'];
    $anio_lanzamiento = $_POST['anio_lanzamiento'];
    $link_img = $_POST['link_img'];

    $controller->updatePelicula($pelicula_id, $titulo, $gen_id, $anio_lanzamiento, $link_img);
    header('Location: view.php');
    exit;
}

if (isset($_GET['id'])) {
    $pelicula_id = $_GET['id'];
    $pelicula = $controller->getPeliculaById($pelicula_id);

    if (!$pelicula) {
        die('Película no encontrada');
    }
} else {
    die('id no especificado');
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Editar Pelicula</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <link rel="stylesheet" href="../CSS/style.css">
</head>

<body>
    <div class="container">
        <h1 class="text-center p-3">Editar Pelicula</h1>
        <form action="edit_process.php" method="POST">
            <input type="hidden" name="pelicula_id" value="<?php echo $pelicula['pelicula_id']; ?>">
            <div class="form-group">
                <label>Titulo:</label>
                <input type="text" name="titulo" class="form-control" value="<?php echo $pelicula['titulo']; ?>" required>
            </div>
            <div class="form-group">
                <label>Genero ID:</label>
                <input type="text" name="gen_id" class="form-control" value="<?php echo $pelicula['gen_id']; ?>" required>
            </div>
            <div class="form-group">
                <label>Año Lanzamiento:</label>
                <input type="text" name="anio_lanzamiento" class="form-control" value="<?php echo $pelicula['anio_lanzamiento']; ?>">
            </div>
            <div class="form-group">
                <label>Link Iamgen:</label>
                <input type="text" name="link_img" class="form-control" value="<?php echo $pelicula['link_img']; ?>">
            </div>
            <button type="submit" class="btn btn-primary">Actualizar</button>
        </form>
    </div>
</body>

</html>
